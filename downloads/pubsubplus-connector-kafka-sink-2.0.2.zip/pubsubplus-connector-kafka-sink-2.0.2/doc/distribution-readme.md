# Solace PubSub+ Connector for Kafka: Sink

This package provides a Solace PubSub+ Event Broker to Kafka Sink Connector. 

For detailed description refer to the project GitHub page at [https://github.com/SolaceProducts/pubsubplus-connector-kafka-sink](https://github.com/SolaceProducts/pubsubplus-connector-kafka-sink)

Package directory contents:

- doc: this readme and license information
- lib: Sink Connector jar file and dependencies
- etc: sample configuration properties and JSON file 
